# NOIR-X-HOST

Personal web-hosting dashboard starter.

## Files
- `index.html` — responsive static dashboard.
- `.nojekyll` — prevents GitHub Pages from applying Jekyll processing.

## Publish the dashboard with GitHub Pages
1. Open this repository on GitHub.
2. Upload `index.html`, `README.md`, and `.nojekyll` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for the Pages deployment URL to appear.

## Important limitation
This repository currently contains only a static frontend demo. The file picker only displays selected local filenames in your browser; it does not upload or host files. It does not execute PHP, Python, or Node.js. Those features require a secure backend, storage, isolated runtime/container execution, domain routing, and resource limits. Do not expose server credentials or run user-uploaded code without sandboxing.
